#!/usr/bin/env python3
"""
autostart_bot.py — Self-contained Node.js setup + bot launcher
--------------------------------------------------------------
✅ Detects Node.js
✅ If missing, downloads Node.js LTS binary locally (no root needed)
✅ Runs `npm install` if needed
✅ Starts bot.js automatically

Usage:
  python3 autostart_bot.py
"""

import os, subprocess, platform, tarfile, urllib.request, shutil, stat, sys

NODE_VERSION = "v20.10.0"
NODE_DIR = ".local_node"
BOT_FILE = "bot.js"

def run(cmd, env=None):
    print(f"\n$ {' '.join(cmd)}")
    subprocess.run(cmd, check=False, env=env)

def ensure_node():
    """Ensure local Node.js binary exists."""
    if shutil.which("node"):
        print("✅ Node.js already available globally.")
        return shutil.which("node")

    node_bin = os.path.join(NODE_DIR, "bin", "node")
    if os.path.exists(node_bin):
        print("✅ Using local Node.js from", NODE_DIR)
        return node_bin

    print("⚙️  Node.js not found. Downloading portable version...")
    sys_os = platform.system().lower()
    arch = "x64"
    if "linux" in sys_os:
        tar_name = f"node-{NODE_VERSION}-linux-{arch}.tar.xz"
    elif "darwin" in sys_os:
        tar_name = f"node-{NODE_VERSION}-darwin-{arch}.tar.xz"
    else:
        print("❌ Unsupported OS:", sys_os)
        sys.exit(1)

    url = f"https://nodejs.org/dist/{NODE_VERSION}/{tar_name}"
    os.makedirs(NODE_DIR, exist_ok=True)
    tar_path = os.path.join(NODE_DIR, tar_name)
    print("⬇️  Downloading:", url)

    urllib.request.urlretrieve(url, tar_path)
    print("📦 Extracting...")
    with tarfile.open(tar_path) as tar:
        tar.extractall(NODE_DIR)
    os.remove(tar_path)

    # Move contents to .local_node/
    extracted = os.path.join(NODE_DIR, f"node-{NODE_VERSION}-linux-{arch}")
    for item in os.listdir(extracted):
        shutil.move(os.path.join(extracted, item), NODE_DIR)
    shutil.rmtree(extracted)
    node_path = os.path.join(NODE_DIR, "bin", "node")
    os.chmod(node_path, stat.S_IRWXU)
    print("✅ Node.js ready (local).")
    return node_path

def ensure_npm_install(node_bin):
    """Run npm install if needed."""
    npm_bin = os.path.join(os.path.dirname(node_bin), "npm")
    env = os.environ.copy()
    env["PATH"] = f"{os.path.dirname(node_bin)}:{env['PATH']}"
    if os.path.exists("package.json"):
        print("📦 Installing npm dependencies...")
        run([node_bin, npm_bin, "install"], env=env)
    else:
        print("⚠️  package.json not found — skipping npm install.")
    return env

def start_bot(node_bin, env):
    """Start the bot.js file."""
    if not os.path.exists(BOT_FILE):
        print(f"❌ Bot file '{BOT_FILE}' not found in", os.getcwd())
        sys.exit(1)
    print(f"🚀 Starting bot ({BOT_FILE}) using {node_bin} ...")
    run([node_bin, BOT_FILE], env=env)

if __name__ == "__main__":
    node_path = ensure_node()
    env = ensure_npm_install(node_path)
    start_bot(node_path, env)
