# 🤖 Cloudways Telegram Auto Account Creator Bot

> **Automatically create Cloudways accounts and receive activation links directly in Telegram!**

## 🎯 Project Overview

**Name**: Cloudways Telegram Bot  
**Goal**: Automatically create Cloudways accounts and monitor activation emails  
**Status**: ✅ Production Ready

### Main Features:
- ✅ Create Cloudways accounts via Telegram command
- ✅ Real-time Cloudways API error reporting (disposable email, etc.)
- ✅ Automatic email monitoring for activation links (IMAP-based)
- ✅ Auto-forward activation links to Telegram
- ✅ Handle all Cloudways API errors with clear messages
- ✅ Random name & password generation
- ✅ Support for multiple email providers (Gmail, Outlook, Yahoo)

## ⚡ Quick Start (5 Minutes)

**New to this bot?** Read [`QUICKSTART.md`](QUICKSTART.md) for 5-minute setup guide!

**Need detailed instructions?** Read [`SETUP_GUIDE.md`](SETUP_GUIDE.md) for complete setup.

**Ready to deploy?** Follow [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md) step-by-step.

## 🚀 Currently Completed Features
1. ✅ Full Cloudways signup API integration with real headers
2. ✅ Telegram bot with `/create` command
3. ✅ Email monitoring system (IMAP-based)
4. ✅ Activation link extraction and forwarding
5. ✅ Error handling with detailed Cloudways responses
6. ✅ Random name and password generation
7. ✅ Bot status and help commands

## 📡 Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome message and bot introduction |
| `/create <email>` | Create new Cloudways account |
| `/help` | Show detailed help message |
| `/status` | Check bot and monitoring status |

### Usage Example:
```
/create myemail@gmail.com
```

Bot will:
1. Create Cloudways account
2. Show credentials (save the password!)
3. Monitor email inbox
4. Send activation link when received

## 🔧 Setup Instructions

### 1. Create Telegram Bot
```bash
# Talk to @BotFather on Telegram
/newbot
# Follow instructions to get your BOT_TOKEN
```

### 2. Setup Email Monitoring (Gmail Example)
```bash
# Enable 2-Factor Authentication on Gmail
# Generate App Password: https://myaccount.google.com/apppasswords
# Copy the 16-character app password
```

### 3. Configure Environment Variables
```bash
# Copy example file
cp .env.example .env

# Edit .env file with your credentials
nano .env
```

Required variables:
```env
TELEGRAM_BOT_TOKEN=your_bot_token_here
IMAP_USER=your-email@gmail.com
IMAP_PASSWORD=your-16-char-app-password
IMAP_HOST=imap.gmail.com
IMAP_PORT=993
IMAP_TLS=true
```

### 4. Install Dependencies
```bash
npm install
```

### 5. Start Bot

#### Development Mode:
```bash
npm start
```

#### Production Mode (PM2):
```bash
npm run start:pm2
npm run logs      # Check logs
npm run status    # Check status
npm run restart   # Restart bot
```

## 📊 Data Architecture

### Data Models:
- **Account Creation Request**: email, first_name, last_name, password, device_id
- **Pending Accounts Map**: email → {chatId, timestamp}
- **Cloudways API Response**: success/error status, credentials, error messages

### Storage Services:
- **In-Memory Storage**: Pending accounts (Map object)
- **IMAP Email Server**: Activation email monitoring
- **Telegram API**: User interactions and notifications

### Data Flow:
1. User sends `/create email@example.com` to Telegram
2. Bot calls Cloudways API with random credentials
3. If successful, store in pendingAccounts Map
4. Start IMAP monitoring for activation email
5. Parse email for activation link
6. Forward link to user via Telegram
7. Remove from pendingAccounts

## 🔍 Features Not Yet Implemented
- [ ] Database storage for account history
- [ ] Multi-user support with user authentication
- [ ] Web dashboard for account management
- [ ] Automatic account verification after activation
- [ ] Bulk account creation
- [ ] Export account list to CSV

## 📈 Recommended Next Steps
1. Add database (SQLite/PostgreSQL) for account history
2. Implement user authentication system
3. Add rate limiting to prevent abuse
4. Create admin panel for monitoring
5. Add notification system for failed creations
6. Implement automatic retry logic

## 🛠️ Tech Stack
- **Runtime**: Node.js
- **Bot Framework**: node-telegram-bot-api
- **HTTP Client**: axios
- **Email Monitoring**: imap-simple + mailparser
- **Process Manager**: PM2

## 🔒 Security Notes
- Never commit `.env` file to git
- Use App Passwords for email access
- Keep Telegram bot token secure
- Monitor for suspicious activity
- Implement rate limiting in production

## 📝 Deployment Status
- **Platform**: Local/VPS (Node.js required)
- **Status**: ✅ Ready to Deploy
- **Requirements**: Node.js 18+, PM2 (optional)
- **Last Updated**: 2025-10-23

## 🐛 Known Issues & Solutions

### Issue: "Disposable email" error
**Solution**: Use valid email providers (Gmail, Outlook, Yahoo)

### Issue: Email monitoring timeout
**Solution**: Check IMAP credentials and firewall settings

### Issue: Bot not responding
**Solution**: Check bot token and restart with `npm run restart`

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [`README.md`](README.md) | This file - Project overview and setup |
| [`QUICKSTART.md`](QUICKSTART.md) | ⚡ 5-minute quick start guide |
| [`SETUP_GUIDE.md`](SETUP_GUIDE.md) | 📖 Detailed setup instructions |
| [`FEATURES.md`](FEATURES.md) | 🎯 Complete features list |
| [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md) | ✅ Deployment checklist |
| [`.env.example`](.env.example) | ⚙️ Environment configuration template |

## 🧪 Testing Tools

```bash
# Test IMAP email connection
npm run test:imap

# Test Cloudways API
npm run test:cloudways test@example.com
```

## 📞 Support & Troubleshooting

### Quick Help:
1. **Bot not responding?** → `npm run restart`
2. **Email not working?** → `npm run test:imap`
3. **API errors?** → `npm run test:cloudways youremail@gmail.com`
4. **Check logs:** → `npm run logs`

### Common Issues:
- **"Disposable email" error** → Use Gmail/Outlook/Yahoo
- **IMAP connection failed** → Check app password and IMAP settings
- **Bot offline** → Run `npm run status` and check logs

For detailed troubleshooting, see [`SETUP_GUIDE.md`](SETUP_GUIDE.md)

## 🌟 Project Stats

- **Total Lines of Code**: 500+
- **Dependencies**: 6 main packages
- **Documentation Pages**: 5
- **Test Scripts**: 2
- **Setup Time**: ~5 minutes
- **Status**: ✅ Production Ready

## 📄 License

MIT License - Free to use and modify

## 🤝 Contributing

This is a complete, working bot. Feel free to:
- Report issues
- Suggest improvements
- Fork and customize
- Add new features

## 🙏 Credits

**Built with:**
- [Hono](https://hono.dev) - Lightweight web framework
- [node-telegram-bot-api](https://github.com/yagop/node-telegram-bot-api) - Telegram bot SDK
- [imap-simple](https://github.com/chadxz/imap-simple) - IMAP email client
- [axios](https://axios-http.com) - HTTP client

---

**Created by**: AI Assistant  
**Version**: 1.0.0  
**Date**: October 2025  
**Repository**: `/home/user/webapp`

⭐ **Star this project if you find it useful!** ⭐
