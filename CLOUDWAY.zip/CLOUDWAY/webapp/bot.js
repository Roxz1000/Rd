const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const Imap = require('imap-simple');
const { simpleParser } = require('mailparser');

// Configuration from environment variables
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '7231986404:AAFy-xBKY8HkiDM0grhDyxi083h_sqF2B9Y';
const IMAP_USER = process.env.IMAP_USER || 'your-email@gmail.com';
const IMAP_PASSWORD = process.env.IMAP_PASSWORD || 'your-app-password';
const IMAP_HOST = process.env.IMAP_HOST || 'imap.gmail.com';
const IMAP_PORT = parseInt(process.env.IMAP_PORT || '993');
const IMAP_TLS = process.env.IMAP_TLS !== 'false';

// Initialize bot
const bot = new TelegramBot(BOT_TOKEN, { polling: true });

// Store user creation requests for email monitoring
const pendingAccounts = new Map();

console.log('🤖 Cloudways Auto Account Creator Bot Started!');

// Generate random name
function generateRandomName() {
  const firstNames = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Avery', 'Quinn', 'Sam', 'Jamie'];
  const lastNames = ['Smith', 'Johnson', 'Brown', 'Davis', 'Wilson', 'Moore', 'Taylor', 'Anderson', 'Thomas', 'Jackson'];
  return {
    first: firstNames[Math.floor(Math.random() * firstNames.length)],
    last: lastNames[Math.floor(Math.random() * lastNames.length)]
  };
}

// Generate random password
function generatePassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#$';
  let password = '';
  for (let i = 0; i < 12; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password + '@' + Math.floor(Math.random() * 999);
}

// Create Cloudways account
async function createCloudwaysAccount(email) {
  const name = generateRandomName();
  const password = generatePassword();
  const deviceId = uuidv4();
  const userUniqueId = uuidv4();

  const payload = {
    first_name: name.first,
    last_name: name.last,
    email: email,
    password: password,
    gdpr_consent: true,
    promo_code: '',
    persona_tag_id: 12,
    signup_price_id: 'b',
    talonData: JSON.stringify({
      '0': 0,
      '2': Math.floor(Math.random() * 999999999),
      '3': '',
      '4': Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
      '5': '',
      '6': 1,
      '7': 0,
      '9': 1,
      'version': '6.0.8',
      'i': '',
      'status': -2,
      'timestamp': new Date().toISOString(),
      'a': {},
      'b': '',
      'c': '',
      'd': '',
      'e': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36'
    }),
    user_unique_id: userUniqueId,
    signup_page_template_id: 0
  };

  const headers = {
    'Host': 'api.cloudways.com',
    'x-device-id': deviceId,
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
    'accept': 'application/json',
    'content-type': 'application/json',
    'sec-ch-ua': '"Brave";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-gpc': '1',
    'accept-language': 'en-IN,en;q=0.8',
    'origin': 'https://unified.cloudways.com',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://unified.cloudways.com/',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'priority': 'u=1, i'
  };

  try {
    const response = await axios.post(
      'https://api.cloudways.com/api/v2/guest/signup',
      payload,
      { headers, timeout: 30000 }
    );

    return {
      success: true,
      data: response.data,
      credentials: {
        email,
        password,
        firstName: name.first,
        lastName: name.last
      }
    };
  } catch (error) {
    if (error.response) {
      return {
        success: false,
        error: error.response.data,
        status: error.response.status
      };
    }
    throw error;
  }
}

// Monitor email for activation link
async function monitorEmailForActivation(email, chatId) {
  const config = {
    imap: {
      user: IMAP_USER,
      password: IMAP_PASSWORD,
      host: IMAP_HOST,
      port: IMAP_PORT,
      tls: IMAP_TLS,
      tlsOptions: { rejectUnauthorized: false },
      authTimeout: 10000
    }
  };

  try {
    const connection = await Imap.connect(config);
    await connection.openBox('INBOX');

    const searchCriteria = [
      'UNSEEN',
      ['FROM', 'cloudways.com'],
      ['TO', email]
    ];

    const fetchOptions = {
      bodies: ['HEADER', 'TEXT', ''],
      markSeen: true
    };

    // Check for emails every 10 seconds for 5 minutes
    let attempts = 0;
    const maxAttempts = 30;

    const checkInterval = setInterval(async () => {
      attempts++;

      try {
        const messages = await connection.search(searchCriteria, fetchOptions);

        if (messages.length > 0) {
          clearInterval(checkInterval);
          connection.end();

          for (const item of messages) {
            const all = item.parts.find(part => part.which === '');
            const parsed = await simpleParser(all.body);

            // Extract activation link
            const activationLinkMatch = parsed.html?.match(/https?:\/\/[^\s<>"]+verify[^\s<>"]*/i) || 
                                       parsed.text?.match(/https?:\/\/[^\s]+verify[^\s]*/i);

            if (activationLinkMatch) {
              const activationLink = activationLinkMatch[0];
              bot.sendMessage(chatId, 
                `✅ *Activation Email Received!*\n\n` +
                `📧 Email: \`${email}\`\n` +
                `🔗 Activation Link:\n${activationLink}\n\n` +
                `Click the link to activate your Cloudways account!`,
                { parse_mode: 'Markdown' }
              );
              pendingAccounts.delete(email);
              return;
            }
          }
        }

        if (attempts >= maxAttempts) {
          clearInterval(checkInterval);
          connection.end();
          bot.sendMessage(chatId, 
            `⏰ *Timeout Warning*\n\n` +
            `Email monitoring timed out for: ${email}\n` +
            `Please check your inbox manually.`,
            { parse_mode: 'Markdown' }
          );
          pendingAccounts.delete(email);
        }
      } catch (err) {
        console.error('Error checking emails:', err);
      }
    }, 10000); // Check every 10 seconds

  } catch (error) {
    console.error('IMAP connection error:', error);
    bot.sendMessage(chatId, 
      `✅❤️ *ACCOUNT CREATED *\n\n` +
      ` check email for activation link.\n` +
      `👾👾👾👾👾👾👾👾👾*\n\n` +
      `Please check your email manually for activation link.`,
      { parse_mode: 'Markdown' }
    );
  }
}

// Bot Commands

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 
    `🚀 *Welcome to Cloudways Auto Account Creator! @Roxz_gaming 🎇*\n\n` +
    `📝 *Commands:*\n` +
    `/create <email> - Create new Cloudways account\n` +
    `/help - Show help message\n` +
    `/status - Check bot status\n\n` +
    `*Example:*\n` +
    `/create myemail@gmail.com\n\n` +
    `⚡ Bot will automatically:\n` +
    `• Create Cloudways account\n` +
    `• Monitor email for activation link\n` +
    `• Send you the activation link\n` +
    `• Show any errors from Cloudways API`,
    { parse_mode: 'Markdown' }
  );
});

bot.onText(/\/help/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 
    `📖 *Help - Cloudways Account Creator*\n\n` +
    `*How to use:*\n` +
    `1. Send: \`/create your@email.com\`\n` +
    `2. Bot will create Cloudways account\n` +
    `3. Wait for activation email\n` +
    `4. Bot will send activation link\n\n` +
    `*Important Notes:*\n` +
    `• Use valid email (no disposable emails)\n` +
    `• Activation link sent within 2-5 minutes\n` +
    `• Bot monitors email automatically\n` +
    `• Real-time Cloudways API errors shown\n\n` +
    `*Supported Email Providers:*\n` +
    `Gmail, Outlook, Yahoo, ProtonMail, etc.`,
    { parse_mode: 'Markdown' }
  );
});

bot.onText(/\/status/, (msg) => {
  const chatId = msg.chat.id;
  const pendingCount = pendingAccounts.size;
  bot.sendMessage(chatId, 
    `📊 *Bot Status*\n\n` +
    `✅ Bot is running\n` +
    `📧 Email monitoring: Active\n` +
    `⏳ Pending accounts: ${pendingCount}\n` +
    `🔄 IMAP Server: ${IMAP_HOST}:${IMAP_PORT}`,
    { parse_mode: 'Markdown' }
  );
});

bot.onText(/\/create (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const email = match[1].trim().toLowerCase();

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    bot.sendMessage(chatId, 
      `❌ *Invalid Email Format*\n\nPlease provide a valid email address.\n\nExample: \`/create myemail@gmail.com\``,
      { parse_mode: 'Markdown' }
    );
    return;
  }

  bot.sendMessage(chatId, 
    `⏳ *Creating Cloudways Account...*\n\n📧 Email: \`${email}\`\n\nPlease wait...`,
    { parse_mode: 'Markdown' }
  );

  try {
    const result = await createCloudwaysAccount(email);

    if (result.success) {
      pendingAccounts.set(email, { chatId, timestamp: Date.now() });

      bot.sendMessage(chatId, 
        `✅ *Account Creation Request Sent!*\n\n` +
        `📧 Email: \`${email}\`\n` +
        `👤 Name: ${result.credentials.firstName} ${result.credentials.lastName}\n` +
        `🔐 Password: \`${result.credentials.password}\`\n\n` +
        `🔍 *Monitoring email for activation link...*\n` +
        `This may take 2-5 minutes.\n\n` +
        `⚠️ *Important:* Save your password!`,
        { parse_mode: 'Markdown' }
      );

      // Start email monitoring
      monitorEmailForActivation(email, chatId);

    } else {
      // Show Cloudways API error
      let errorMessage = `❌ *Cloudways Signup Error*\n\n`;
      
      if (result.error) {
        if (typeof result.error === 'string') {
          errorMessage += `Error: ${result.error}\n`;
        } else if (result.error.message) {
          errorMessage += `Message: ${result.error.message}\n`;
        } else if (result.error.email) {
          // Handle email validation errors
          const emailErrors = Array.isArray(result.error.email) 
            ? result.error.email.join(', ') 
            : result.error.email;
          errorMessage += `Email Error: ${emailErrors}\n`;
        } else {
          errorMessage += `Error: ${JSON.stringify(result.error, null, 2)}\n`;
        }
      }

      errorMessage += `\nHTTP Status: ${result.status}\n`;
      errorMessage += `Risk Level: N/A\n\n`;
      errorMessage += `💡 *Common Issues:*\n`;
      errorMessage += `• Disposable email detected\n`;
      errorMessage += `• Email already registered\n`;
      errorMessage += `• Invalid email domain\n`;
      errorMessage += `• Rate limit exceeded`;

      bot.sendMessage(chatId, errorMessage, { parse_mode: 'Markdown' });
    }

  } catch (error) {
    bot.sendMessage(chatId, 
      `❌ *Unexpected Error*\n\n` +
      `Error: ${error.message}\n\n` +
      `Please try again later or contact support.`,
      { parse_mode: 'Markdown' }
    );
    console.error('Error creating account:', error);
  }
});

// Error handling
bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('Unhandled rejection:', error);
});

console.log('✅ Bot is ready to receive commands!');
